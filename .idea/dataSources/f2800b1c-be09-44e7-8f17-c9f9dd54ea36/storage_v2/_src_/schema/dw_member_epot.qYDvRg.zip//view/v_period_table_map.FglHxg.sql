CREATE VIEW v_period_table_map AS
  SELECT
    `p`.`ID`         AS `ID`,
    `p`.`REGION_ID`  AS `OUTLINE`,
    `o`.`id`         AS `OUTLET`,
    `p`.`NAME`       AS `NAME`,
    `pt`.`ROOM_NUM`  AS `ROOM_NUM`,
    `pt`.`MINPERSON` AS `MINPERSON`,
    `pt`.`MAXPERSON` AS `MAXPERSON`,
    `p`.`STIME`      AS `STIME`,
    `p`.`ETIME`      AS `ETIME`
  FROM ((`dw_member_epot`.`tb_mem_period` `p` LEFT JOIN `dw_member_epot`.`tb_outlet` `o`
      ON ((`p`.`OUTLET` = `o`.`id`))) LEFT JOIN `dw_member_epot`.`tb_pos_table` `pt`
      ON (((`pt`.`OUTLINE` = `p`.`REGION_ID`) AND (`o`.`OUTLET` = `pt`.`OUTLET`))));

