CREATE PROCEDURE pro_kvsprint(IN p_outline VARCHAR(50), IN p_outlet VARCHAR(50), IN p_startdate VARCHAR(10),
                              IN p_enddate VARCHAR(10))
  BEGIN
	#Routine body goes here...
SELECT a.outlet,lt.NAME1 outname,a.in_date,a.table_num,a.PERSON,a.REF_NUM,a.SUB_REF,b.ITEM_CODE,em.DESC1,b.QTY,
	(case when (UNIX_TIMESTAMP(rm.min_time) - UNIX_TIMESTAMP(b.T_TIME)) = 0 then '首單' when (UNIX_TIMESTAMP(rm.min_time) - UNIX_TIMESTAMP(b.T_TIME)) > 7200 then '尾單' else '加單' end)as order_type,
	 b.t_time,lg.t_time printTime,em.PRN
FROM tb_pos_tran a INNER JOIN tb_pos_order b 
on a.outline=b.outline and a.outlet=b.outlet and a.REF_NUM=b.REF_NUM and a.SUB_REF=b.SUB_REF and a.TRAN_TYPE=b.TYPE
inner join tb_pos_table tt
on a.OUTLINE=tt.outline and a.TABLE_NUM=tt.ROOM_NUM
LEFT JOIN 
(
	select rd.outline,rd.outlet,rd.type,rd.REF_NUM,rd.SUB_REF, MIN(rd.T_TIME) as min_time 
	from 
		tb_pos_order rd
	LEFT JOIN 
		tb_pos_item t
	on rd.ITEM_CODE=t.item_code  and rd.outline=t.outline 
	where t.CAT not in ('054','007') and rd.TYPE ='N' and rd.OUTLINE=p_outline and rd.outlet=p_outlet
	GROUP BY rd.outline,rd.outlet,rd.type,rd.REF_NUM,rd.SUB_REF
) rm 
on a.outline=rm.outline and a.outlet=rm.outlet and a.tran_type=rm.type and a.ref_num=rm.ref_num and a.sub_ref=rm.sub_ref
left join 
	tb_pos_log lg
on b.outline=lg.outline and b.outlet=lg.outlet and b.type=lg.type and b.ref_num=lg.ref_num and b.sub_ref=lg.sub_ref and b.item_idx=lg.t_index
left join 
	tb_pos_item em
on b.outline=em.outline and b.item_code=em.item_code
left join 
	tb_outlet lt
on a.OUTLET=lt.OUTLET and a.OUTLINE=lt.REGION_ID
where a.OUTLINE=p_outline and a.outlet=p_outlet and a.tran_type='N' 
AND CONCAT(a.IN_DATE,' ',a.IN_TIME)>=concat(p_startdate,' ','04:00:00') AND  CONCAT(a.IN_DATE,' ',a.IN_TIME)<=concat(p_enddate,' ','04:00:00')
and b.qty>0 and tt.ROOM_TYPE!='S' and em.CAT not in ('054','007')
order by a.IN_DATE,a.REF_NUM,b.T_TIME;
END;

