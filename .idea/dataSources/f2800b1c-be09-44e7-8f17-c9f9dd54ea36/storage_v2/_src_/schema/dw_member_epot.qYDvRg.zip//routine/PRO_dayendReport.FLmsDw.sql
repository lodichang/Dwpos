CREATE PROCEDURE PRO_dayendReport(IN p_outline VARCHAR(50), IN p_outlet VARCHAR(50), IN p_startdate VARCHAR(10),
                                  IN p_enddate VARCHAR(10))
  BEGIN
	DECLARE d_outlet,d_outletName VARCHAR(50);
	DECLARE d_start_billdate,d_start_billtime,d_end_billdate,d_end_billtime VARCHAR(50);
	DECLARE d_discqty int;
	DECLARE d_discount_amt decimal(18,2);
	DECLARE d_unpay int;
	DECLARE d_server_amt,d_billamt,d_rounding,d_order_disc decimal(18,2);
	DECLARE d_count,d_person int;
	DECLARE d_endref,d_startref varchar(25);
	DECLARE d_endtime,d_starttime varchar(6);
	DECLARE d_time varchar(15);
	DECLARE d_bill varchar(50);
	DECLARE d_cancelbill,d_changebill,d_zerobill int;
	DECLARE d_order_disc1,d_order_amt DECIMAL(18,2);
	DECLARE d_pay_disc DECIMAL(18,2);

	declare d_desc varchar(100);	-- 付款方式名称
	DECLARE d_qty int;			-- 付款次数
	DECLARE	d_amt,d_free_amt decimal(18,2);	-- 付款金额--免费
	
	DECLARE D_SCAT_CODE CHAR(3);
	DECLARE D_SCAT_DESC1 VARCHAR(100);
	DECLARE done INT DEFAULT FALSE; -- 自定义控制游标循环变量,默认false  
	DECLARE SCAT_CURSOR CURSOR  FOR   -- 定义游标并输入结果集 
			SELECT DISTINCT A.CODE,A.DESC1 FROM 
			(
				SELECT CODE,DESC1 FROM tb_pos_scat WHERE OUTLINE=p_outline
			) A
			LEFT JOIN 
			(
				SELECT DISTINCT SCAT,CAT_CODE FROM tb_pos_category WHERE OUTLINE=p_outline
			) B
			ON A.CODE=B.SCAT
			RIGHT JOIN 
			(
				SELECT  DISTINCT CAT 
				FROM tb_pos_item ITEM
				WHERE OUTLINE=p_outline
					AND EXISTS (
						SELECT DISTINCT ITEM_CODE 
						FROM tb_pos_order a
						WHERE TYPE='N' AND OUTLET=p_outlet  AND OUTLINE=p_outline
							and EXISTS (
								select  REF_NUM from tb_pos_tran B
								where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet  
								AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
								AND a.REF_NUM=B.REF_NUM AND a.OUTLET=B.OUTLET AND a.SUB_REF=B.SUB_REF AND a.OUTLET=B.OUTLET AND a.OUTLINE=B.OUTLINE
						) 
						AND a.ITEM_CODE=ITEM.ITEM_CODE
				)	
			) C
			ON B.CAT_CODE=C.CAT
			ORDER BY A.CODE;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 绑定控制变量到游标,游标循环结束自动转true 

	drop table if exists tmp_table;
	CREATE TEMPORARY TABLE tmp_table (
			temp_name VARCHAR(100) DEFAULT '',
			temp_count VARCHAR(100) DEFAULT '',
			temp_amt DECIMAL(18,2) DEFAULT 0.00,
			temp_signed INT
	);

	select OUTLET,NAME1 INTO d_outlet,d_outletName from tb_outlet where OUTLET=p_outlet AND REGION_ID=p_outline;
	
  
	select  IFNULL(BILL_DATE,''),IFNULL(BILL_TIME,'') INTO d_start_billdate,d_start_billtime
	from tb_pos_tran 
	where TRAN_TYPE='N' AND OUTLET=p_outlet and ifnull(settled,'')='TRUE' AND OUTLINE=p_outline
		AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
	order by BILL_DATE ,BILL_TIME  
	limit 0,1;
	
	select IFNULL(BILL_DATE,''),IFNULL(BILL_TIME,'') INTO d_end_billdate,d_end_billtime
	from tb_pos_tran 
	where  TRAN_TYPE='N' AND OUTLET=p_outlet and ifnull(settled,'')='TRUE' AND OUTLINE=p_outline
		AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
	order by BILL_DATE desc,BILL_TIME desc
	limit 0,1;

	INSERT INTO tmp_table values(d_outlet,d_outletName,null,1);
	insert into tmp_table values(CONCAT(CAST(d_start_billdate as char(10)),' ',d_start_billtime),CONCAT(convert(d_end_billdate,char(10)),' ',d_end_billtime),null,2);
	insert into tmp_table values('*账单资料*',null,null,3);
	-- 现金代用券金额(代金券的确认方式是，编号是以C开头，并且不是现金的付款方式)
	select count(*),ifnull(SUM(NET_AMOUNT),0) into d_discqty,d_discount_amt
	from tb_pos_pay A
	where TRAN_TYPE = 'N' and PAY_TYPE like 'C%' and PAY_TYPE!= 'CASH' 
		AND EXISTS (
			SELECT REF_NUM from tb_pos_tran B
			where  TRAN_TYPE ='N'  and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline
				AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
				AND OUTLET=p_outlet AND A.REF_NUM=B.REF_NUM AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET
				AND A.OUTLINE=B.OUTLINE
		);

	-- 未付款账单数
	select COUNT(*) into d_unpay
	from 
	(
		select * from tb_pos_tran a 
		where TRAN_TYPE='N' AND OUTLET=p_outlet AND OUTLINE=p_outline
			AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
	) a 
	where TRAN_TYPE='N' and ifnull(SETTLED,'')='FALSE'; 

	-- 开始和结束时间，开始和结束单号,人数，食品价，找零差额,点菜折扣
	select SUM(ifnull(SERV_AMT,0.00)),count(*),MAX(REF_NUM),MIN(REF_NUM),MAX(convert(BILL_TIME,char(5))),MIN(convert(BILL_TIME,char(5))),sum(PERSON),SUM(ifnull(BILL_AMT,0.00)),
		SUM(ifnull(ROUNDING,0.00)),SUM(ifnull(ORDER_DISC,0.00)) into d_server_amt,d_count,d_endref,d_startref,d_endtime,d_starttime,d_person,d_billamt,d_rounding,d_order_disc
	from tb_pos_tran  
	where TRAN_TYPE ='N' and ifnull(SETTLED,'')='TRUE' AND OUTLET=p_outlet AND OUTLINE=p_outline
		AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00'); 
	
	set d_time = concat(d_starttime,'-',d_endtime); 
	
	if LENGTH(d_startref)>8 then
		set d_startref = SUBSTRING(d_startref,11,LENGTH(d_startref)-9);
		set d_endref = SUBSTRING(d_endref,11,LENGTH(d_endref)-9);
	end if;
	set d_bill = concat(d_startref,'-',d_endref);
		
	-- 改单
	select COUNT(*) into d_changebill from tb_pos_tran
	where TRAN_TYPE ='A' and ifnull(SETTLED,'')='TRUE'
		AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
		AND OUTLET=p_outlet AND OUTLINE=p_outline ;
		
	-- 消单 
	select COUNT(*) into d_cancelbill from tb_pos_tran 
	where TRAN_TYPE ='V'  and ifnull(SETTLED,'')='TRUE'
		AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
		AND OUTLET=p_outlet AND OUTLINE=p_outline ;
		
	-- 零单
	select count(*) into d_zerobill from tb_pos_tran 
	where TRAN_TYPE='N'  and ifnull(SETTLED,'')='TRUE'
		AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
		AND OUTLET=p_outlet AND OUTLINE=p_outline and BILL_AMT=0 ; 	

	-- 食品折扣
	
	SELECT SUM(AMT+IFNULL(serv_cost,0.00)-ifnull(ORDER_DISC,0)),SUM(AMT+IFNULL(serv_cost,0.00)),SUM(ifnull(ORDER_DISC,0)) into d_order_disc1,d_order_amt,d_order_disc
	FROM tb_pos_order A
	WHERE LEFT(REF_NUM,10)>=p_startdate AND LEFT(REF_NUM,10)<=p_enddate AND OUTLET=p_outlet AND OUTLINE=p_outline AND TYPE='N'
		AND EXISTS (
			SELECT REF_NUM from tb_pos_tran B
			where  TRAN_TYPE ='N'  and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline
				AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
				AND OUTLET=p_outlet AND A.REF_NUM=B.REF_NUM AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET
				AND A.OUTLINE=B.OUTLINE
		);
		
	-- 付款折扣匯總 
	select sum(AMT1) into d_pay_disc
	from tb_pos_log a 
	left join 
	(
		SELECT * FROM tb_pos_payment WHERE OUTLINE=p_outline
	) b 
	on a.REMARK1 = b.CODE 
	where a.LOG_TYPE in ('XJZK','GZZK') and a.TYPE = 'N' and OUTLET=p_outlet
		and EXISTS (
			select REF_NUM from tb_pos_tran  C
			where  TRAN_TYPE ='N' and SETTLED = 'TRUE' AND OUTLINE=p_outline
				AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')
				AND OUTLET=p_outlet AND a.REF_NUM=C.REF_NUM AND a.SUB_REF=C.SUB_REF AND a.OUTLET=C.OUTLET
				AND a.OUTLINE=C.OUTLINE
		);

	-- 插入显示数据
	insert into	tmp_table	values('结账时间',d_time,null,'5');
	insert into	tmp_table	values('单号',d_bill,null,'6');
	/*
		2013-06-12 11:49 薛修改项目名为“未结账单数”，并修改了统计内容 
	*/
	insert into	tmp_table	values('结账单数',d_unpay,null,'8');
	insert into	tmp_table	values('消单',d_cancelbill,null,'8');
	insert into	tmp_table	values('改单',d_changebill,null,'9');
	insert into	tmp_table	values('单数',d_count,null,'10');
	insert into	tmp_table	values('人数',d_person,null,'11');
	insert into	tmp_table	values('零单',d_zerobill,null,'12');
	insert into	tmp_table	values('食品价',null,cast(IFNULL(d_order_amt,0.00) as char),'13');
	insert into	tmp_table	values('付款折扣',null,cast(IFNULL(d_pay_disc,0.00) as char),'14');
	insert into	tmp_table	values('点菜折扣',null,cast(IFNULL(d_order_disc,0.00)-IFNULL(d_pay_disc,0.00) as char),'14');
	
	-- --集团折扣券   付款折扣			
	insert into tmp_table 
		select b.DESC1,a.COUNT_NUM,cast(a.AMT as decimal(18,2)),'15' 
		from (
			select REMARK1,COUNT(*) COUNT_NUM,sum(AMT1) AMT 
			from tb_pos_log A
			where LOG_TYPE in ('XJZK','GZZK') and TYPE = 'N' and OUTLET=p_outlet
				and EXISTS (
					select REF_NUM from tb_pos_tran  B
					where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     
					AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
					AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
				)
			group by REMARK1  
		) a 
		left join 
		(
			SELECT * FROM tb_pos_payment WHERE OUTLINE=p_outline
		) b 
		on a.REMARK1 = b.CODE;
			
	insert into	tmp_table values('找零差额',null,d_rounding,'16');
	insert into	tmp_table values('代用折扣券',null,d_discount_amt,'17');
	insert into	tmp_table values('总单价',null,IFNULL(d_order_disc1,0.00)-IFNULL(d_discount_amt,0.00)+IFNULL(d_rounding,0.00),'18');
		

	-- 总售额
	/*
	--主要记录今天所有的收入，包括订金和预付卡充值等
	*/
	
	-- 营业总收额 
	insert into tmp_table values('*总收额*',null,null,'19');
	insert into  tmp_table
		select c.DESC1,b.QTY,b.AMT+b.OVER_AMT+b.TIPS,'20' 
		from 
		(
			select a.PAY_TYPE,count(*) QTY,sum(a.NET_AMOUNT) AMT,-SUM(a.OVER_AMT) OVER_AMT,-SUM(a.TIPS) TIPS
			from 
			(
				select * from tb_pos_pay A
				where TRAN_TYPE ='N' 
					and EXISTS (
						select REF_NUM from tb_pos_tran  B
						where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
						AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
						AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
					) 
			) a  
			group by a.PAY_TYPE
		) b 
		left join 
		(
			SELECT * FROM tb_pos_payment WHERE OUTLINE=p_outline
		) c 
		on b.PAY_TYPE = c.CODE ;

	
	-- 插入统计数据
	insert into  tmp_table
		select '营业总收额',b.QTY,b.AMT+b.OVER_AMT+b.TIPS,'21'
		from 
		(
			select count(*) QTY,sum(a.NET_AMOUNT) AMT,-SUM(a.OVER_AMT) OVER_AMT ,-SUM(a.TIPS) TIPS
			from 
			(
				select * from tb_pos_pay A
				where TRAN_TYPE ='N' 
					and EXISTS (
						select REF_NUM from tb_pos_tran  B
						where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
						AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
						AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
					) 
			) a  
		) b; 		
		
		
	-- 免费金额
	select SUM(AMT) into d_free_amt
	from tb_pos_order A
	where FREE !=0 and `TYPE` ='N' 
		and EXISTS (
			select REF_NUM from tb_pos_tran  B
			where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
			AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
			AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
		)
		AND LEFT(REF_NUM,10)>=p_startdate AND LEFT(REF_NUM,10)<=p_enddate AND OUTLINE=p_outline AND OUTLET=p_outlet ;
	
	insert into tmp_table values ('免费金额',null,d_free_amt,'22'),('代用折扣券',d_discqty,d_discount_amt,'23');


		
		
	insert into tmp_table values ('*总收额*',null,null,'24'),('付款方式','次数',NULL,'25');
	insert into  tmp_table
	select c.DESC1,b.QTY,b.AMT+b.OVER_AMT+b.TIPS,'26'
	from (
		select a.PAY_TYPE,count(*) QTY,sum(a.NET_AMOUNT) AMT,-SUM(a.OVER_AMT) OVER_AMT ,-SUM(a.TIPS) TIPS
		from 
		(
			select * from tb_pos_pay A
			where TRAN_TYPE ='N' 
				and EXISTS (
					select  REF_NUM from tb_pos_tran  B
					where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
					AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
					AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
				)
		)a  group by a.PAY_TYPE
	) b 
	left join 
	(
		SELECT * FROM tb_pos_payment WHERE OUTLINE=p_outline
	) c 
	on b.PAY_TYPE = c.CODE ;
		
		
	-- 插入统计数据
	insert into tmp_table
	select '总收额',b.QTY,b.AMT+b.OVER_AMT+b.TIPS,'27'
	from (
		select count(*) QTY,sum(a.NET_AMOUNT) AMT,-SUM(a.OVER_AMT) OVER_AMT,-SUM(a.TIPS) TIPS
		from (
			select * from tb_pos_pay A
			where TRAN_TYPE ='N' 
				and EXISTS (
					select  REF_NUM from tb_pos_tran  B
					where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
					AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
					AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
				)
		)a  
	) b ;
	


	-- 货币
	insert into tmp_table values('*货币*',null,null,'28');
	insert into  tmp_table
		select b.CURRENCY,b.QTY,b.AMT+b.OVER_AMT+b.TIPS,'29'
		from (
			select a.CURRENCY,count(*) QTY,sum(a.NET_AMOUNT) AMT,-SUM(a.OVER_AMT) OVER_AMT,-SUM(a.TIPS) TIPS 
			from (
				select * from tb_pos_pay A
				where TRAN_TYPE ='N' -- and PAY_TYPE = 'CASH' 
					and EXISTS (
						select  REF_NUM from tb_pos_tran  B
						where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
						AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
						AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
					)
			)a  group by a.CURRENCY
		) b ;



	-- 插入统计数据
	insert into tmp_table
		select '总收额',b.QTY,b.AMT+b.OVER_AMT+b.TIPS,'30'
		from (
			select count(*) QTY,sum(a.NET_AMOUNT) AMT,-SUM(a.OVER_AMT) OVER_AMT,-SUM(a.TIPS) TIPS
			from (
				select * from tb_pos_pay A
				where TRAN_TYPE ='N' -- and PAY_TYPE = 'CASH' 
					and EXISTS (
						select  REF_NUM from tb_pos_tran  B
						where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
						AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
						AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
					)
			)a  
		) b ;

	-- 新增付款折扣
	insert into tmp_table values('*付款折扣*',null,null,'31');					
	insert into tmp_table 
		select b.DESC1,a.COUNT_NUM,a.AMT,'32'
		from (
			select REMARK1,COUNT(*) COUNT_NUM,sum(AMT1) AMT 
			from tb_pos_log A
			where LOG_TYPE in ('XJZK','GZZK','YFZK') and TYPE = 'N' 
				and EXISTS (
					select  REF_NUM from tb_pos_tran  B
					where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
					AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
					AND A.REF_NUM=B.REF_NUM AND A.OUTLET=B.OUTLET AND A.SUB_REF=B.SUB_REF AND A.OUTLET=B.OUTLET AND A.OUTLINE=B.OUTLINE
				)
			group by REMARK1  
		) a 
		left join 
		(
			SELECT * FROM tb_pos_payment WHERE OUTLINE=p_outline
		) b 
		on a.REMARK1 = b.CODE;

	insert into tmp_table 
		select '总计',COUNT(*),sum(AMT1) AMT,'33'
		from tb_pos_log a 
		left join 
		(
			SELECT * FROM tb_pos_payment WHERE OUTLINE=p_outline
		) b 
		on a.REMARK1 = b.CODE 
		where a.LOG_TYPE in ('XJZK','GZZK','YFZK') and a.TYPE = 'N' 
			and EXISTS (
				select  REF_NUM from tb_pos_tran  B
				where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
				AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
				AND a.REF_NUM=B.REF_NUM AND a.OUTLET=B.OUTLET AND a.SUB_REF=B.SUB_REF AND a.OUTLET=B.OUTLET AND a.OUTLINE=B.OUTLINE
			);	

	-- 大类销售信息
	insert into tmp_table values('*大类销售*',null,null,'34');
		

		
		OPEN SCAT_CURSOR ;
		myloop: loop
			FETCH SCAT_CURSOR INTO D_SCAT_CODE,D_SCAT_DESC1;
			if done then
				leave myloop;
			end if;
			INSERT INTO tmp_table  VALUES(D_SCAT_DESC1,null,null,'35');
			INSERT INTO tmp_table 
			SELECT concat(C.CAT,'',D.DESC1) ,C.COU,C.AMT,'35' FROM (
				SELECT SUM(A.AMT) AMT,SUM(A.COU) COU,B.CAT 
				FROM (
					select ITEM_CODE,SUM(AMT) AMT,SUM(QTY+CANCEL+FREE) COU 
					from tb_pos_order a
					where type='N' AND OUTLINE=p_outline AND OUTLET=p_outlet
						and EXISTS (
							select  REF_NUM from tb_pos_tran B
							where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
							AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
							AND a.REF_NUM=B.REF_NUM AND a.OUTLET=B.OUTLET AND a.SUB_REF=B.SUB_REF AND a.OUTLET=B.OUTLET AND a.OUTLINE=B.OUTLINE
						) 
					GROUP BY ITEM_CODE
				) A 
				LEFT JOIN 
				(
					SELECT * FROM tb_pos_item WHERE OUTLINE=p_outline
				) B 
				ON A.ITEM_CODE=B.ITEM_CODE 
				GROUP BY B.CAT
			) C 
			INNER JOIN 
			(
				SELECT * FROM tb_pos_category WHERE OUTLINE=p_outline AND SCAT=D_SCAT_CODE
			) D 
			ON C.CAT=D.CAT_CODE
			ORDER BY C.CAT ;
			
			INSERT INTO tmp_table 
			SELECT '总计',SUM(C.COU) COU,SUM(C.AMT) AMT,'35'
			FROM (
				SELECT SUM(A.AMT) AMT,SUM(A.COU) COU,B.CAT 
				FROM (
					select ITEM_CODE,SUM(AMT) AMT,SUM(QTY+CANCEL+FREE) COU 
					from tb_pos_order a
					where type='N' AND OUTLINE=p_outline AND OUTLET=p_outlet
						and EXISTS (
							select  REF_NUM from tb_pos_tran B
							where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
							AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
							AND a.REF_NUM=B.REF_NUM AND a.OUTLET=B.OUTLET AND a.SUB_REF=B.SUB_REF AND a.OUTLET=B.OUTLET AND a.OUTLINE=B.OUTLINE
						) 
					GROUP BY ITEM_CODE
				) A 
				LEFT JOIN 
				(
					SELECT * FROM tb_pos_item WHERE OUTLINE=p_outline
				) B 
				ON A.ITEM_CODE=B.ITEM_CODE 
				GROUP BY B.CAT
			) C 
			INNER JOIN 
			(
				SELECT * FROM tb_pos_category WHERE OUTLINE=p_outline AND SCAT=D_SCAT_CODE
			) D 
			ON C.CAT=D.CAT_CODE
			GROUP BY D.SCAT;
			
		END loop myloop;
		CLOSE SCAT_CURSOR;
		
		
		
		INSERT INTO tmp_table 
			SELECT '*大类总计*',SUM(C.COU) COU,SUM(C.AMT) AMT,'37' 
			FROM (
				select SUM(AMT) AMT,SUM(QTY+CANCEL+FREE) COU 
				from tb_pos_order a
				where type='N' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
					and EXISTS (
						select  REF_NUM from tb_pos_tran B
						where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet    
						AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
						AND a.REF_NUM=B.REF_NUM AND a.OUTLET=B.OUTLET AND a.SUB_REF=B.SUB_REF AND a.OUTLET=B.OUTLET AND a.OUTLINE=B.OUTLINE
				) 
			) C ;
		-- 转更资料
		insert into tmp_table values('转更资料',null,null,'38');

		insert into tmp_table 
			select CONCAT('机号',CAST(STATION_ID AS CHAR)),max(PERIOD),null,'39'
			from  tb_pos_tran
			where  TRAN_TYPE ='N' and ifnull(SETTLED,'') = 'TRUE' AND OUTLINE=p_outline AND OUTLET=p_outlet     	
			AND CONCAT(IN_DATE,' ',IN_TIME)>=concat(p_startdate,' ','04:00:00') AND CONCAT(IN_DATE,' ',IN_TIME)<=concat(p_enddate,' ','04:00:00')	
			group by STATION_ID  ;

			
    SELECT * FROM tmp_table ORDER BY temp_signed;
	
	TRUNCATE TABLE tmp_table;
	DROP TABLE tmp_table;
END;

